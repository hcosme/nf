<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta http-equiv="Content-Style-Type" content="text/css" />
      <meta name="generator" content="Aspose.Words for .NET 23.3.0" />
      <title></title>
      <style type="text/css">body { line-height:115%; font-family:Calibri; font-size:11pt }h1, p { margin:0pt 0pt 10pt }li, table { margin-top:0pt; margin-bottom:10pt }h1 { margin-bottom:0pt; text-align:center; page-break-inside:auto; page-break-after:avoid; line-height:normal; font-family:'Bookman Old Style'; font-size:11pt; font-weight:bold; color:#000000 }.BalloonText { margin-bottom:0pt; line-height:normal; font-family:Tahoma; font-size:8pt }.Footer { margin-bottom:0pt; line-height:normal; font-size:11pt }.Header { margin-bottom:0pt; line-height:normal; font-size:11pt }.ListParagraph { margin-left:36pt; margin-bottom:10pt; line-height:115%; font-size:11pt }.PlainText { margin-bottom:0pt; line-height:normal; font-family:Calibri; font-size:11pt }span.TextodebaloChar { font-family:Tahoma; font-size:8pt }span.TextosemFormataoChar { font-family:Calibri }span.Ttulo1Char { font-family:'Bookman Old Style'; font-weight:bold }.TableGrid {  }</style>
   <script>
        window.print();
   </script>
   </head>
   <body>
      <div>
         <div style="-aw-headerfooter-type:header-primary; clear:both">
            <p style="margin-bottom:0pt; line-height:115%; font-size:20pt"><span style="font-family:Arial; font-weight:bold; color:#404040; -aw-import:ignore">&#xa0;</span></p>
            <p style="margin-bottom:0pt; line-height:115%; font-size:20pt"><img src="https://cdn.izap.com.br/tlpservicos.com.br/plus/images?src=tema/plusfiles/3_Logotipo---TLP-cortado.png&" width="181" height="55" alt="Logotipo TLP" style="margin-right:9pt; margin-left:9pt; -aw-left-pos:355.24pt; -aw-rel-hpos:column; -aw-rel-vpos:paragraph; -aw-top-pos:2.65pt; -aw-wrap-type:through; float:right; position:relative" /><span style="font-family:Arial; font-weight:bold; color:#404040">ADVERTÊNCIA DISCIPLINAR</span></p>
            <p style="margin-bottom:0pt; line-height:150%; font-size:10pt"><span style="font-family:Arial; color:#404040">Advertência </span><span style="font-family:Arial; color:#ff0000">Não Cumprimento Procedimento Operacional</span></p>
         </div>
         <p style="margin-bottom:0pt; line-height:200%"><span style="-aw-import:ignore">&#xa0;</span></p>
         <p style="margin-bottom:0pt; line-height:200%"><span style="-aw-import:ignore">&#xa0;</span></p>
         <p style="margin-bottom:0pt; text-align:justify; line-height:normal; font-size:9pt"><span style="font-family:Arial; color:#808080; -aw-import:ignore">&#xa0;</span></p>
         <p style="margin-bottom:0pt; text-align:justify; line-height:250%; font-size:9pt"><span style="font-family:Arial; color:#808080; -aw-import:ignore">&#xa0;</span></p>
         <p style="text-indent:35.4pt; text-align:justify; line-height:250%; font-size:9pt"><span style="font-family:Arial; font-weight:bold; color:#808080">Sr. </span><span style="font-family:Arial; font-weight:bold; color:#ff0000">{{ $dados['dados'][0]->colaborador }}</span><span style="font-family:Arial; font-weight:bold; color:#808080">, CPF: </span><span style="font-family:Arial; font-weight:bold; color:#ff0000">{{ $dados['dados'][0]->cpf }}</span><span style="font-family:Arial; font-weight:bold; color:#808080">, vimos informar-lhe que, pelo fato de ter incidido em ato de desídia e insubordinação no desempenho de sua função (art. 482, “e” e “h” da CLT) </span><span style="font-family:Arial; font-weight:bold; color:#7f7f7f">por “</span><span style="font-family:Arial; font-weight:bold; color:#ff0000">{{ $dados['dados'][0]->consideracoes }}</span><span style="font-family:Arial; font-weight:bold; color:#7f7f7f">.” na data </span><span style="font-family:Arial; font-weight:bold; color:#ff0000">{{ date('d/m/Y', strtotime($dados['dados'][0]->data_ocorrido)) }}</span><span style="font-family:Arial; font-weight:bold; color:#7f7f7f">. Salientamos que tal práti</span><span style="font-family:Arial; font-weight:bold; color:#808080">ca, consiste em uma conduta contrária às regras internas de caráter operacional e administrativo prejudicando o correto desenvolvimento do trabalho, motivo pelo qual está sendo advertido.</span></p>
         <p style="text-indent:35.4pt; text-align:justify; line-height:250%; font-size:9pt"><span style="font-family:Arial; font-weight:bold; color:#808080">Dessa forma o mesmo está sendo advertido de forma escrita em razão de sua conduta! Salienta-se que o ato praticado pelo colaborador bem como serviu de mau exemplo para os demais colaboradores. Este ato é previsto a dispensa por justa causa na CLT, art. 482, letras “h”, ato de indisciplina ou de insubordinação.</span></p>
         <p style="text-align:center; line-height:250%; font-size:9pt"><span style="font-family:Arial; color:#ff0000">São Paulo, 
         
         <?php
            setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
            date_default_timezone_set('America/Sao_Paulo');
            echo strftime('%d de %B de %Y', strtotime('today'));
         
         ?>
         
         .</span></p>
         <p style="margin-bottom:0pt; text-align:justify; line-height:normal; font-size:9pt"><span style="font-family:Arial; color:#808080; -aw-import:ignore">&#xa0;</span></p>
         <p style="margin-bottom:0pt; text-align:justify; line-height:normal"><span style="-aw-import:spaces">&#xa0;</span></p>
         <p style="margin-bottom:0pt; text-align:center; line-height:normal; font-size:9pt"><span style="font-family:Arial; color:#808080; -aw-import:ignore">&#xa0;</span></p>
         <p style="margin-bottom:0pt; text-align:center; line-height:normal; font-size:9pt"><span style="font-family:Arial; color:#808080; -aw-import:ignore">&#xa0;</span></p>
         <table cellspacing="0" cellpadding="0" class="TableGrid" style="margin-bottom:0pt; border-collapse:collapse">
            <tr style="height:43.55pt">
               <td style="width:229.9pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                  <p style="margin-bottom:0pt; text-align:center; line-height:150%; font-size:9pt"><span style="font-family:Arial; color:#808080">_____________________________________________</span><br /><span style="line-height:150%; font-family:Arial; font-size:8pt; color:#808080">TELEPERFORMANCE TELECOMUNICAÇÕES LTDA</span></p>
                  <p style="margin-bottom:0pt; font-size:9pt"><span style="font-family:Arial; color:#808080; -aw-import:ignore">&#xa0;</span></p>
               </td>
               <td style="width:229.95pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                  <p style="margin-bottom:0pt; text-align:center; line-height:150%; font-size:9pt"><span style="font-family:Arial; color:#808080">_____________________________________________</span><br /><span style="line-height:150%; font-family:Arial; font-size:8pt; color:#ff0000">{{ $dados['dados'][0]->colaborador }}</span><br /><span style="line-height:150%; font-family:Arial; font-size:8pt; color:#ff0000">CPF: {{ $dados['dados'][0]->cpf }}</span></p>
               </td>
            </tr>
         </table>
         <p style="margin-bottom:0pt; text-align:center; line-height:normal; font-size:9pt"><span style="font-family:Arial; color:#808080; -aw-import:ignore">&#xa0;</span></p>
         <p style="margin-bottom:0pt; text-align:justify; line-height:normal; font-size:9pt"><span style="font-family:Arial; color:#808080; -aw-import:ignore">&#xa0;</span></p>
         <p style="margin-bottom:0pt; text-align:justify; line-height:normal; font-size:9pt"><span style="font-family:Arial; color:#808080; -aw-import:ignore">&#xa0;</span></p>
         <p style="margin-bottom:0pt; text-align:justify; line-height:normal; font-size:9pt"><span style="width:35.4pt; font-family:Arial; display:inline-block">&#xa0;</span><span style="width:35.4pt; font-family:Arial; display:inline-block">&#xa0;</span></p>
         <table cellspacing="0" cellpadding="0" class="TableGrid" style="margin-bottom:0pt; border-collapse:collapse">
            <tr style="height:43.55pt">
               <td style="width:229.9pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                  <p style="margin-bottom:0pt; text-align:center; line-height:150%; font-size:9pt"><span style="font-family:Arial; color:#808080">_____________________________________________</span><br /><span style="line-height:150%; font-family:Arial; font-size:8pt; color:#808080">TESTEMUNHA</span></p>
                  <p style="margin-bottom:0pt; font-size:9pt"><span style="font-family:Arial; color:#808080; -aw-import:ignore">&#xa0;</span></p>
               </td>
               <td style="width:229.95pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                  <p style="margin-bottom:0pt; text-align:center; line-height:150%; font-size:9pt"><span style="font-family:Arial; color:#808080">_____________________________________________</span><br /><span style="line-height:150%; font-family:Arial; font-size:8pt; color:#808080">TESTEMUNHA</span></p>
               </td>
            </tr>
         </table>
         <p style="margin-bottom:0pt; text-align:justify; line-height:normal; font-size:9pt"><span style="width:35.4pt; font-family:Arial; display:inline-block">&#xa0;</span><span style="width:35.4pt; font-family:Arial; display:inline-block">&#xa0;</span></p>
      </div>
   </body>
</html>