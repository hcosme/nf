<?php $__env->startSection('title', 'Equipes'); ?>

<?php $__env->startSection('content_header'); ?>
<!--<meta http-equiv="refresh" content="30">
   <h1 class="m-0 text-dark">Report Instalação</h1> -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style>
   .blink_me {
  animation: blinker 5s linear infinite;
}

#circuloVermelho {
width: 10px;
height: 10px;
border-radius: 50%;
background-color: #FF0000;
margin: 0px;
}

@keyframes  blinker {  
  50% { opacity: 0; }
}

</style>

    <div class="callout callout-secondary">
  <p>

            <form role="form" method="post" action="./novo_lancamento_presenca" enctype="multipart/form-data">
           <?php echo e(csrf_field()); ?>

    <div class="row">
      <div class="col-12">
    <div class="box-body table-responsive no-padding">
        <table id="" class="table table-striped table-sm table-bordered ">
            <thead>
                <tr class="bg-light text-center py-0 align-middle">
                    <th style=" background-color:#;color:black;width:200px" colspan="19"><center>[APONTAR PRESENÇA - <?php echo $dados['dados'][0]->credenciadas;?>] </th> 
                </tr>
                <tr class="bg-light text- py-0 align-middle">
                    <th style=" background-color:#;color:black;width:160px"><center>Nome</th>
                    <th style=" background-color:#;color:black;width:80px"><center>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php 
                $numero = 1;
                foreach ($dados['dados'] as $gr) {
                    echo '<tr class="bg- text- py-0 align-middle">
                            <td> <input type="text" class="form-control form-control-sm" name="tecnicos[]" style="background:#" value="'.$gr->tecnicos.'" readonly=""></td>
                           <td><center> 
                                <select name="status[]" class="form-control form-control-sm" value="">
                                    <option value="Presente">Presente</option>
                                    <option value="Falta">Falta</option>
                                    <option value="Folga">Folga</option>
                                    <option value="Frota">Frota</option>
                                    <option value="Atestado">Atestado</option>
                                    <option value="Outros">Outros</option>
                                </select>
                            </td>
                    ';
                }
            ?>

    </tbody>
  </table>
  <button type="submit" class="btn btn-success">Salvar</button> </a>
                <a href="./index"><button type="button" class="btn btn-secondary">Retornar</button> </a>
              </div><br>
            </form>
        </div>
      </div>
      </div>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/hcontr25/ligue.gestaoderecursos.com/ligue/resources/views/apontar-presenca-credenciada.blade.php ENDPATH**/ ?>