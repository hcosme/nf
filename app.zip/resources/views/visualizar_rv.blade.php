<html lang="pt-br" class="js-focus-visible" data-js-focus-visible="" data-arp-injected="true"><head>

  <meta charset="utf-8">

  <title></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta name="description" content="-----//-----">



<style type="text/css">
@font-face {
  font-weight: 400;
  font-style:  normal;
  font-family: 'Circular-Loom';

  src: url('https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Book-cd7d2bcec649b1243839a15d5eb8f0a3.woff2') format('woff2');
}

@font-face {
  font-weight: 500;
  font-style:  normal;
  font-family: 'Circular-Loom';

  src: url('https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Medium-d74eac43c78bd5852478998ce63dceb3.woff2') format('woff2');
}

@font-face {
  font-weight: 700;
  font-style:  normal;
  font-family: 'Circular-Loom';

  src: url('https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Bold-83b8ceaf77f49c7cffa44107561909e4.woff2') format('woff2');
}

@font-face {
  font-weight: 900;
  font-style:  normal;
  font-family: 'Circular-Loom';

  src: url('https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Black-bf067ecb8aa777ceb6df7d72226febca.woff2') format('woff2');
}</style></head>


<body><div style="width: 100%;" align="">

<table style="text-align: left; width: 1260px; height: 200px;" border="2" cellpadding="2" cellspacing="2">

  <tbody>

    <tr>

      <td style="width: 175px;">

      <div style="text-align: center;">
      </div>
		<img style="width: 160px; height: 160px;" alt="" src="https://ffainfraestrutura.com.br/wp-content/uploads/2020/09/Logo_png02-200x123.png"><br>		

      </td>

      <td style="width: 845px;text-align: center;">

      <h1>EXTRATO RV</h1>
FFA INFRAESTRUTURA<br>

RESULTADO DE ENTREGA E QUALIDADE - RV
      <br> <?php echo $dados['informacao'][0]->NOME;?> - <?php echo $dados['informacao'][0]->CPF;?><br>
      </td>

    </tr>

    <tr>

      <td style="width: 175px; text-align: center;">		FFA INFRAESTRUTURA </td>
      <td style="width: 845px; text-align: center;"><b>   Situação:</b>
        <b><?php
            if ($dados['informacao'][0]->SITUACAO == 0) {
                echo 'Inelegível';
            } else {
                echo 'Elegível';
            }
            ?> - <?php echo $dados['informacao'][0]->TIPO;?> - <?php echo $dados['informacao'][0]->SKILL;?> | <b>Data de Atualização:</b> <?php echo date('d/m/Y H:i:s', strtotime($dados['informacao'][0]->ATUALIZACAO));?> </span></td>
    </tr>

  
  </tbody>
</table>
<br>


  <table align="" width="100%"  table#lista="" thead{="" position:="" fixed;="" }="" cellspacing="0" cellpadding="0" table="" style="table-layout: fixed; width: 1250px; overflow: hidden;">
                    <thead>
           

	
	<tr>

 Segundo a politica de bonificação criada pela empresa FFA Infraestrutura, inscrita no CNPJ 08.375.450/0001-70, o colaborador descrito no título,
        obteve os seguintes resultados abaixo e receberá o valor de <b>R$ <?php echo $dados['informacao'][0]->VALOR_TOTAL;?></b>. Resultado abaixo:</p>

        <b>Presença:</b><br>
         FTTH: <?php echo $dados['informacao'][0]->PRESENCA_H;?> | FTTC: <?php echo ($dados['informacao'][0]->PRESENCA_C);?> 
        <p>
    
        <b>Produção:</b><br>
       
          Instalações FTTH: <?php echo $dados['informacao'][0]->INSTALACAO_H;?>  - R$<?php echo $dados['informacao'][0]->VALOR_H;?> 
        | Instalações FTTC: <?php echo $dados['informacao'][0]->INSTALACAO_C;?>  - R$<?php echo $dados['informacao'][0]->VALOR_C;?> 
        | Reparo FTTH: <?php echo $dados['informacao'][0]->BILHETE_H;?> 
        | Reparo FTTC: <?php echo $dados['informacao'][0]->BILHETE_C;?> 
        | Desconexões FTTH: 0 
        | Desconexões FTTC: 0
<br>
         Prod. Instalações FTTH: <?php echo $dados['informacao'][0]->PROD_INST_FTTH;?> 
        | Prod. Instalações FTTC: <?php echo $dados['informacao'][0]->PROD_INST_FTTC;?>
        | Prod. Reparo FTTH: <?php echo $dados['informacao'][0]->PROD_REP_FTTH;?> 
        | Prod. Reparo FTTC: <?php echo $dados['informacao'][0]->PROD_REP_FTTC;?> 
        <p>
  
         <b>Efetividade (Se o colaborador for de Reparo aparecerá zerado):</b><br>
         Atividades encerradas OK: <?php echo $dados['informacao'][0]->ACERTOS_EFETIVIDADE;?> | Atividades Informadas: <?php echo ($dados['informacao'][0]->EFETIVIDADE_EXECUTAD-$dados['informacao'][0]->ACERTOS_EFETIVIDADE);?> | Taxa: <?php echo $dados['informacao'][0]->EFETIVIDADE;?> R$<?php echo $dados['informacao'][0]->EFETIVIDADE_VALOR;?>
        <p>

         <b>Repetida:</b><br>
         Atividades Executadas: <?php echo $dados['informacao'][0]->REP_ENCERRADOS;?> | Atividades Repetidas: <?php echo $dados['informacao'][0]->REP_REPETIDOS;?> | Taxa: <?php echo $dados['informacao'][0]->INDICADOR_REPETIDA;?> R$ <?php echo $dados['informacao'][0]->REPETIDA_VALOR;?>
         <p>
    
          <b>Recente:</b><br>
         Atividades Executadas: <?php echo $dados['informacao'][0]->INST_EXECUTADAS;?> | Atividades recentes: <?php echo $dados['informacao'][0]->REP_RECENTE;?> | Taxa: <?php echo $dados['informacao'][0]->INDICADOR_RECENTE;?> R$ <?php echo $dados['informacao'][0]->RECENTE_VALOR;?>
         <p>
     
        <b>TT Base:</b><br>
         Taxa: <?php echo $dados['informacao'][0]->INDICADOR;?> R$ <?php echo $dados['informacao'][0]->TT_BASE_VALOR;?>
         <p>
      
          <b>TREA:</b><br>
         TREA não entregue: <?php echo $dados['informacao'][0]->TREA_N_ENTREGUE;?> R$ <?php echo $dados['informacao'][0]->VALOR_TOTAL_TREA;?> 
         <p>
       
           <b>RNC:</b><br>
         RNC Não Corrigida: <?php echo $dados['informacao'][0]->QUANTIDADE_RNC;?> R$ <?php echo $dados['informacao'][0]->VALOR_TOTAL_RNC;?> 
       
     
</tr>

<br>
<center>
<br><br><br>

__________________________________________________________________________________________________<br>

   <?php echo $dados['informacao'][0]->NOME;?> | DATA EMISSAO: <?php  date_default_timezone_set('America/Sao_Paulo'); echo date('d/m/Y H:i:s');?></center></div></body>
   <loom-container id="lo-engage-ext-container">
       <loom-shadow classname="resolved"></loom-shadow></loom-container>
       </html>