<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/welcome', function () {
    return view('welcome');
});

Auth::routes();



Route::get('/frota', [App\Http\Controllers\FrotaController::class, 'index'])->middleware('auth');



Route::get('/indicadores', [App\Http\Controllers\IndicadoresController::class, 'index'])->middleware('auth');


Route::get('/home', [App\Http\Controllers\InstalacaoController::class, 'online'])->middleware('auth');
Route::get('/instalacao', [App\Http\Controllers\InstalacaoController::class, 'index'])->middleware('auth');
Route::get('/instalacao_online', [App\Http\Controllers\InstalacaoController::class, 'online'])->middleware('auth');
Route::get('/reparo_online', [App\Http\Controllers\ReparoController::class, 'online'])->middleware('auth');
Route::get('/abertas', [App\Http\Controllers\ReparoController::class, 'abertas'])->middleware('auth');
Route::get('/abertasRj', [App\Http\Controllers\ReparoController::class, 'abertasRj'])->middleware('auth');
Route::get('/import', [App\Http\Controllers\InstalacaoController::class, 'import'])->middleware('auth');
Route::post('/importing', [App\Http\Controllers\InstalacaoController::class, 'importing'])->middleware('auth');
Route::get('/instalacao_online_tecnico', [App\Http\Controllers\InstalacaoController::class, 'onlineTecnico'])->middleware('auth');
Route::get('/reparo_online_tecnico', [App\Http\Controllers\ReparoController::class, 'onlineTecnico'])->middleware('auth');
Route::get('/reparo', [App\Http\Controllers\ReparoController::class, 'index'])->middleware('auth');
Route::get('/indicadores', [App\Http\Controllers\IndicadoresController::class, 'index'])->middleware('auth');
Route::get('/recente', [App\Http\Controllers\InstalacaoController::class, 'recente'])->middleware('auth');
Route::get('/recente_tecnico', [App\Http\Controllers\InstalacaoController::class, 'recenteTecnico'])->middleware('auth');



Route::get('/backlog_tlp', [App\Http\Controllers\InstalacaoController::class, 'backlog_tlp'])->middleware('auth');
Route::get('/backlog_tlp_rep', [App\Http\Controllers\InstalacaoController::class, 'backlog_tlp_rep'])->middleware('auth');

Route::get('/backlog_tlp', [App\Http\Controllers\InstalacaoController::class, 'backlog_tlp'])->middleware('auth');
Route::get('/backlog_tlp_rep', [App\Http\Controllers\InstalacaoController::class, 'backlog_tlp_rep'])->middleware('auth');


Route::get('/producao_acumulada', [App\Http\Controllers\ProducaoController::class, 'index'])->middleware('auth');
Route::get('/producao_tecnico_consolidado', [App\Http\Controllers\ProducaoController::class, 'indexTecnico'])->middleware('auth');

Route::get('/indicadores_prazo', [App\Http\Controllers\IndicadoresController::class, 'index'])->middleware('auth');
Route::get('/bases', [App\Http\Controllers\IndicadoresController::class, 'atualizacao'])->middleware('auth');

Route::get('/servidor_bases', [App\Http\Controllers\IndicadoresController::class, 'sinalServidor']);
Route::get('/servidor_extracao', [App\Http\Controllers\IndicadoresController::class, 'sinalServidorExt']);



Route::get('/intra-hora-reparo', [App\Http\Controllers\InstalacaoController::class, 'intra_hora_reparo'])->middleware('auth');
Route::get('/intra-hora-instalacao', [App\Http\Controllers\InstalacaoController::class, 'intra_hora_instalacao'])->middleware('auth');



Route::get('/repetido', [App\Http\Controllers\ReparoController::class, 'repetido'])->middleware('auth');
Route::get('/repetido_tecnico', [App\Http\Controllers\ReparoController::class, 'repetidoTecnico'])->middleware('auth');

Route::get('/reparo_fila', [App\Http\Controllers\ReparoController::class, 'filaAtendimento'])->middleware('auth');


Route::get('/envioTelegram', [App\Http\Controllers\ReparoController::class, 'envioTelegram'])->middleware('auth');

Route::get('/acessos', [App\Http\Controllers\ReparoController::class, 'acessos'])->middleware('auth');

Route::get('/ponto1', [App\Http\Controllers\PontoController::class, 'index'])->middleware('auth');
Route::get('/ponto', [App\Http\Controllers\PontoController::class, 'index1'])->middleware('auth');

Route::get('/horas', [App\Http\Controllers\PontoController::class, 'horas'])->middleware('auth');


Route::get('/detalhe', [App\Http\Controllers\PontoController::class, 'detalhe'])->middleware('auth');
Route::get('/tratar', [App\Http\Controllers\PontoController::class, 'tratar'])->middleware('auth');
Route::get('/laudo', [App\Http\Controllers\PontoController::class, 'laudo'])->middleware('auth');


Route::get('/propenso', [App\Http\Controllers\ReparoController::class, 'propenso'])->middleware('auth');
Route::get('/tratarPropenso', [App\Http\Controllers\ReparoController::class, 'tratarPropenso'])->middleware('auth');
Route::post('/gravarHistoricoPropenso', [App\Http\Controllers\ReparoController::class, 'gravarHistoricoPropenso'])->middleware('auth');

Route::get('/rv', [App\Http\Controllers\RvController::class, 'index'])->middleware('auth');
Route::get('/rv1', [App\Http\Controllers\RvController::class, 'index1'])->middleware('auth');
Route::get('/visualizar_rv', [App\Http\Controllers\RvController::class, 'ver'])->middleware('auth');

/* PRAZO TELEGRAM */
Route::get('/prazo_rj', [App\Http\Controllers\ReparoController::class, 'prazo_rj'])->middleware('auth');
Route::get('/prazo_sp', [App\Http\Controllers\ReparoController::class, 'prazo_sp'])->middleware('auth');

/* ATRIBUICAO */
Route::get('/atribuicao_rj', [App\Http\Controllers\ReparoController::class, 'atribuicao_rj'])->middleware('auth');
Route::get('/atribuicao_sp', [App\Http\Controllers\ReparoController::class, 'atribuicao_sp'])->middleware('auth');

/* FLAG COMPLETAMENTO */
Route::get('/flag_completamento', [App\Http\Controllers\CertificacaoController::class, 'flag_completamento_instalacao'])->middleware('auth');
Route::get('/flag_completamento_reparo', [App\Http\Controllers\CertificacaoController::class, 'flag_completamento_reparo'])->middleware('auth');

/* PRAZO */
Route::get('/menu', [App\Http\Controllers\HomeController::class, 'menu'])->middleware('auth');

/* PRAZO */
Route::get('/prazo_agendamento', [App\Http\Controllers\PrazoController::class, 'prazo_agendamento'])->middleware('auth');
Route::get('/prazo_sla', [App\Http\Controllers\PrazoController::class, 'prazo_sla'])->middleware('auth');

/* TESTE FINAL */
Route::get('/', [App\Http\Controllers\TesteFinalController::class, 'index'])->middleware('auth')->name('testefinal');
Route::get('/testefinal', [App\Http\Controllers\TesteFinalController::class, 'index'])->middleware('auth')->name('testefinal');
Route::get('/cadastroTf', [App\Http\Controllers\TesteFinalController::class, 'cadastrar'])->middleware('auth');
Route::post('/cadastrar-testefinal', [App\Http\Controllers\TesteFinalController::class, 'cadastrarTesteFinal'])->middleware('auth');
Route::get('/editar-testefinal', [App\Http\Controllers\TesteFinalController::class, 'editar'])->middleware('auth')->name('editar-testefinal');
Route::post('/editar-testefinal', [App\Http\Controllers\TesteFinalController::class, 'editarTesteFinal'])->middleware('auth');

Route::get('/vago', [App\Http\Controllers\PosController::class, 'vago'])->middleware('auth');

/* PÓS */
Route::get('/pos', [App\Http\Controllers\PosController::class, 'index'])->middleware('auth');
Route::get('/pos-dashboard', [App\Http\Controllers\PosController::class, 'dashboard'])->middleware('auth');
Route::get('/editar-pos', [App\Http\Controllers\PosController::class, 'editar'])->middleware('auth');
Route::post('/editarPos', [App\Http\Controllers\PosController::class, 'editarPos'])->middleware('auth');

Route::get('/pos-proativo', [App\Http\Controllers\PosController::class, 'proativo'])->middleware('auth');
Route::get('/pos-despachados', [App\Http\Controllers\PosController::class, 'despachados'])->middleware('auth');
Route::get('/editar-pos-despachar', [App\Http\Controllers\PosController::class, 'editar_despachar'])->middleware('auth');
Route::post('/editarPos-despachado', [App\Http\Controllers\PosController::class, 'editarPos_despachar'])->middleware('auth');

/* ADVERTÊNCIAS */
Route::get('/advertencia', [App\Http\Controllers\AdvertenciaController::class, 'index'])->middleware('auth');
Route::get('/cadastro-advertencia', [App\Http\Controllers\AdvertenciaController::class, 'cadastrar'])->middleware('auth');
Route::post('/cadastrar-advertencia', [App\Http\Controllers\AdvertenciaController::class, 'cadastrarAdvertencia'])->middleware('auth');
Route::get('/editar-advertencia', [App\Http\Controllers\AdvertenciaController::class, 'editar'])->middleware('auth');
Route::post('/editar-advertencia', [App\Http\Controllers\AdvertenciaController::class, 'editarAdvertencia'])->middleware('auth');
Route::get('/ver-advertencia', [App\Http\Controllers\AdvertenciaController::class, 'ver'])->middleware('auth');
Route::get('/ver-anexo-advertencia', [App\Http\Controllers\AdvertenciaController::class, 'ver_anexo'])->middleware('auth');


/* BRIGADA DE QUALIDADE */
Route::get('/brigada', [App\Http\Controllers\BrigadaController::class, 'index'])->middleware('auth'); // OK
Route::get('/cadastrar_brigada', [App\Http\Controllers\BrigadaController::class, 'cadastrar'])->middleware('auth'); // OK
Route::post('/cadastrar_brigada', [App\Http\Controllers\BrigadaController::class, 'cadastrarBrigada'])->middleware('auth'); // OK
Route::get('/editar_brigada', [App\Http\Controllers\BrigadaController::class, 'editar'])->middleware('auth'); // OK
Route::post('/editar_brigada', [App\Http\Controllers\BrigadaController::class, 'editarBrigada'])->middleware('auth'); // OK
Route::get('/excluir_brigada', [App\Http\Controllers\BrigadaController::class, 'excluir'])->middleware('auth'); // OK
Route::get('/atualizar_brigada', [App\Http\Controllers\BrigadaController::class, 'atualizar'])->middleware('auth'); // OK
Route::post('/atualizar_brigada', [App\Http\Controllers\BrigadaController::class, 'atualizarBrigada'])->middleware('auth');
Route::get('/ver_brigada', [App\Http\Controllers\BrigadaController::class, 'ver'])->middleware('auth');



Route::get('/home', [App\Http\Controllers\HeadcountController::class, 'apontar_presenca'])->name('home');
Route::get('/apontar_presencat', [App\Http\Controllers\HeadcountController::class, 'apontar_presenca'])->name('home');
Route::get('/index', [App\Http\Controllers\HeadcountController::class, 'index'])->name('index');
Route::get('/apontar_presenca', [App\Http\Controllers\HeadcountController::class, 'apontar_presenca'])->name('apontar_presenca');
Route::get('/lancar_presenca', [App\Http\Controllers\HeadcountController::class, 'lancar_presenca'])->name('lancar_presenca');
Route::post('/novo_lancamento_presenca', [App\Http\Controllers\HeadcountController::class, 'novo_lancamento_presenca'])->name('novo_lancamento_presenca');
Route::get('/editar_apontamento_tecnico', [App\Http\Controllers\HeadcountController::class, 'editar_apontamento_tecnico'])->name('editar_apontamento_tecnico');
Route::get('/ver_apontamento_tecnico', [App\Http\Controllers\HeadcountController::class, 'ver_apontamento_tecnico'])->name('ver_apontamento_tecnico');
Route::post('/editar_apontamento_tecnico_atualizar', [App\Http\Controllers\HeadcountController::class, 'editar_apontamento_tecnico_atualizar'])->name('editar_apontamento_tecnico_atualizar');
Route::get('/deletar_tecnico', [App\Http\Controllers\HeadcountController::class, 'deletar_tecnico'])->name('deletar_tecnico');
Route::get('/deletar_apontamento', [App\Http\Controllers\HeadcountController::class, 'deletar_apontamento'])->name('deletar_apontamento');

// TABULADOR
Route::get('/tabulador-index', [App\Http\Controllers\TabuladorController::class, 'index'])->name('tabulador-index');
Route::get('/tabulador-read', [App\Http\Controllers\TabuladorController::class, 'read'])->name('tabulador-read');
Route::get('/tabulador-edit', [App\Http\Controllers\TabuladorController::class, 'edit'])->name('tabulador-edit');
Route::post('/tabulador-update', [App\Http\Controllers\TabuladorController::class, 'update'])->name('tabulador-update');
Route::get('/tabulador-delete', [App\Http\Controllers\TabuladorController::class, 'delete'])->name('tabulador-delete');
Route::get('/tabulador-operadores', [App\Http\Controllers\TabuladorController::class, 'operadores'])->name('tabulador-operadores');
Route::get('/tabulador-tratada', [App\Http\Controllers\TabuladorController::class, 'tratada'])->name('tabulador-tratada');

// USUARIOS
Route::get('/usuarios', [App\Http\Controllers\UsuariosController::class, 'index'])->name('home');
Route::get('/editar_usuario', [App\Http\Controllers\UsuariosController::class, 'editar_usuario'])->name('editar_usuario');
Route::post('/editar_usuario_alterar', [App\Http\Controllers\UsuariosController::class, 'editar_usuario_alterar'])->name('editar_usuario_alterar');
Route::get('/deletar_usuario', [App\Http\Controllers\UsuariosController::class, 'deletar_usuario'])->name('deletar_usuario');
Route::get('/alterar_senha', [App\Http\Controllers\UsuariosController::class, 'alterar_senha'])->name('alterar_senha');
Route::post('/alterar_senha_alterar', [App\Http\Controllers\UsuariosController::class, 'alterar_senha_alterar'])->name('alterar_senha_alterar');
Route::get('/alterar_senha', [App\Http\Controllers\UsuariosController::class, 'alterar_senha'])->name('alterar_senha');


Route::get('/home_presenca_controlador', [App\Http\Controllers\HeadcountController::class, 'home_presenca_controlador'])->name('home_presenca_controlador');
Route::get('/lancar_presenca_controlador', [App\Http\Controllers\HeadcountController::class, 'lancar_presenca_controlador'])->name('lancar_presenca_controlador');
Route::post('/novo_lancamento_presenca_controlador', [App\Http\Controllers\HeadcountController::class, 'novo_lancamento_presenca_controlador'])->name('novo_lancamento_presenca_controlador');
Route::get('/apontar_presenca_controlador', [App\Http\Controllers\HeadcountController::class, 'apontar_presenca_controlador'])->name('apontar_presenca_controlador');
Route::get('/alterar_presenca_controlador', [App\Http\Controllers\HeadcountController::class, 'alterar_presenca_controlador'])->name('alterar_presenca_controlador');
Route::get('/editar_apontamento_tecnico_controlador', [App\Http\Controllers\HeadcountController::class, 'editar_apontamento_tecnico_controlador'])->name('editar_apontamento_tecnico_controlador');
Route::get('/ver_apontamento_tecnico_controlador', [App\Http\Controllers\HeadcountController::class, 'ver_apontamento_tecnico_controlador'])->name('ver_apontamento_tecnico_controlador');
Route::post('/editar_apontamento_tecnico_atualizar_controlador', [App\Http\Controllers\HeadcountController::class, 'editar_apontamento_tecnico_atualizar_controlador'])->name('editar_apontamento_tecnico_atualizar_controlador');





Route::get('/recente', [App\Http\Controllers\InstalacaoController::class, 'recente'])->middleware('auth');
Route::get('/repetido', [App\Http\Controllers\InstalacaoController::class, 'repetido'])->middleware('auth');

Route::get('/apontamentos_pendentes', [App\Http\Controllers\HeadcountController::class, 'apontamentos_pendentes'])->name('apontamentos_pendentes');
Route::get('/cadastrar_tecnico', [App\Http\Controllers\HeadcountController::class, 'cadastrar_tecnico'])->name('cadastrar_tecnico');
Route::post('/cadastrar_tecnico', [App\Http\Controllers\HeadcountController::class, 'cadastrar_tecnico_novo'])->name('cadastrar_tecnico_novo');
Route::get('/editar_tecnico', [App\Http\Controllers\HeadcountController::class, 'editar_tecnico'])->name('editar_tecnico');
Route::post('/editar_tecnico_novo', [App\Http\Controllers\HeadcountController::class, 'editar_tecnico_novo'])->name('editar_tecnico_novo');
Route::get('/alterar_presenca', [App\Http\Controllers\HeadcountController::class, 'alterar_presenca'])->name('alterar_presenca');






Route::get('/intrahora', [App\Http\Controllers\IntraController::class, 'index'])->name('intrahora');


Route::get('/cq', [App\Http\Controllers\CqController::class, 'cq'])->name('cq');
Route::get('/realizar_cq', [App\Http\Controllers\CqController::class, 'realizar_cq'])->name('realizar_cq');
Route::post('/realizar_cq', [App\Http\Controllers\CqController::class, 'realizar_cq_gravar'])->name('realizar_cq_gravar');
Route::get('/editar_cq', [App\Http\Controllers\CqController::class, 'editar_cq'])->name('editar_cq');
Route::post('/editar_cq', [App\Http\Controllers\CqController::class, 'editar_cq_gravar'])->name('editar_cq_gravar');
Route::get('/ver_cq', [App\Http\Controllers\CqController::class, 'ver_cq'])->name('ver_cq');
Route::get('/visualizar_cq', [App\Http\Controllers\CqController::class, 'visualizar_cq'])->name('visualizar_cq');
Route::get('/', [App\Http\Controllers\HeadcountController::class, 'apontar_presenca'])->name('home');
// rotas para o upload dos arquivos
Route::prefix('file')->group(function () {

    Route::get('/create/{type}/{order_id}', [App\Http\Controllers\FileController::class, 'create'])->name('file.create');

    Route::post('/upload', [App\Http\Controllers\FileController::class, 'store'])->name('file.upload');

    Route::get('/edit/{type}/{order_id}', [App\Http\Controllers\FileController::class, 'edit'])->name('file.edit');

    Route::post('/approve/{id}', [App\Http\Controllers\FileController::class, 'approve'])->name('file.approve');

    Route::post('/reprove/{id}', [App\Http\Controllers\FileController::class, 'reprove'])->name('file.approve');

    Route::post('/upload/operador', [App\Http\Controllers\FileController::class, 'store_operador'])->name('file.upload.operador');
});

