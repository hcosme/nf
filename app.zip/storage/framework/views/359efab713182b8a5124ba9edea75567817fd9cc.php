<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home4/hcontr25/gestaoderecursos.com/hc/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>