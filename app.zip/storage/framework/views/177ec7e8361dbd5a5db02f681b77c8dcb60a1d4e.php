<?php $__env->startSection('title', 'Requisitos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Check List</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>Requisito</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                        </thead>
                        <tbody>
                            <form id="form" action="<?php echo e(route('file.upload')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="order_id" value="<?php echo e($order_id); ?>">
                                <?php $__currentLoopData = $requisitos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $status = "Aguardando envio"
                                    ?>
                                    <?php if($requirements->count() > 0): ?>
                                        <?php
                                            $status = $requirements->where('name', $requisito)->first()->status;
                                        ?>
                                    <?php endif; ?>
                                    <tr class="">
                                        <td><?php echo e($requisito); ?></td>
                                        <td><?php echo e($status); ?></td>
                                        <td>
                                            <?php if($status != "Aprovado" && $status != "Aguardando Aprovaçao"): ?>
                                                <?php if($requisito == 'Fechamento'): ?>
                                                    <select name="<?php echo e($requisito); ?>" id="<?php echo e($requisito); ?>" class="form-control">
                                                        <?php $__currentLoopData = $fechamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fechamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($fechamento->fechamento); ?>" ><?php echo e($fechamento->fechamento); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                <?php else: ?>
                                                    <input type="file" name="<?php echo e($requisito); ?>">
                                                    <?php $__errorArgs = ['requirement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" style="display: revert;" role="alert">
                                                            <strong>
                                                                Este documento é obrigatório.
                                                            </strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </form>
                        </tbody>
                    </table>
                    <br>
                    <button onclick="submit()" class="btn btn-primary float-sm-right">
                        Enviar
                    </button>
                    <a href="<?php echo e(route('testefinal')); ?>" class="btn btn-default float-sm-right mr-2">
                        Voltar
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        function submit() {
            document.getElementById("form").submit();
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/hcontr25/tlp.gestaoderecursos.com/resources/views/files/create.blade.php ENDPATH**/ ?>