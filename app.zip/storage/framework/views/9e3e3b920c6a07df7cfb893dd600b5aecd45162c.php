<?php echo e($slot); ?>

<?php /**PATH /home4/hcontr25/gestaoderecursos.com/hc/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>