<?php $__env->startSection('title', 'Requisitos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Check list</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>Requisito</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                        </thead>
                        <tbody class="table-one">
                            <?php if($requirements->count() > 0): ?>
                                <?php $__currentLoopData = $requisitos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $status = "Aguardando envio"
                                    ?>
                                    <?php if($requirements->count() > 0): ?>
                                        <?php
                                            $requirement = $requirements->where('name', $requisito)->first();
                                            $status = $requirement->status;
                                        ?>
                                    <?php endif; ?>
                                    <tr class="">
                                        <td><?php echo e($requisito); ?></td>
                                        <td><?php echo e($status); ?></td>
                                        <td>
                                            <?php if(questionsOperation($requisito)): ?>
                                                <a class="btn btn-light btn-sm" title="Ver documento" href="<?php echo e($requirement->file ? asset('storage/' . $requirement->file->path) : null); ?>" target="_blank">
                                                    <i class="fas fa-solid fa-eye"></i>
                                                </a>
                                                <a class="btn btn-light btn-sm" title="Baixar documento" href="<?php echo e($requirement->file ? asset('storage/' . $requirement->file->path) : null); ?>" download="<?php echo e($requisito); ?>">
                                                    <i class="fas fa-solid fa-download"></i>
                                                </a>
                                            <?php endif; ?>
                                            <?php if($status != "Aprovado" && $status != "Reprovado"): ?>
                                                <button title="Aprovar" onclick="aprove(<?php echo e($requirement->id); ?>, 'table-one')" class="btn btn-success btn-sm">
                                                    <i class="fas fa-solid fa-check"></i>
                                                </button>
                                                <button title="Reprovar" onclick="reprove(<?php echo e($requirement->id); ?>, 'table-one')" type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target=".bd-example-modal-lg">
                                                    <i class="fas fa-solid fa-times"></i>
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3">
                                        Essa ordem ainda não foi atendida;
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <table class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>Requisito</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                        </thead>
                        <tbody class="table-two">
                            <?php if($requirements->count() > 0): ?>
                                <?php $__currentLoopData = $requirements_aditional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $status = "Aguardando envio"
                                    ?>
                                    <?php if($requirements->count() > 0): ?>
                                        <?php
                                            $requirement = $requirements->where('name', $requisito)->first();
                                            $status = $requirement->status;
                                        ?>
                                    <?php endif; ?>
                                    <tr class="">
                                        <td><?php echo e($requisito); ?></td>
                                        <td><?php echo e($status); ?></td>
                                        <td>
                                            <?php if(questionsOperation($requisito)): ?>
                                                <a class="btn btn-light btn-sm" title="Ver documento" href="<?php echo e($requirement->file ? asset('storage/' . $requirement->file->path) : null); ?>" target="_blank">
                                                    <i class="fas fa-solid fa-eye"></i>
                                                </a>
                                                <a class="btn btn-light btn-sm" title="Baixar documento" href="<?php echo e($requirement->file ? asset('storage/' . $requirement->file->path) : null); ?>" download="<?php echo e($requisito); ?>">
                                                    <i class="fas fa-solid fa-download"></i>
                                                </a>
                                            <?php endif; ?>
                                            <?php if($status != "Aprovado" && $status != "Reprovado"): ?>
                                                <button title="Aprovar" onclick="aprove(<?php echo e($requirement->id); ?>, 'table-two')" class="btn btn-success btn-sm">
                                                    <i class="fas fa-solid fa-check"></i>
                                                </button>
                                                <button title="Reprovar" onclick="reprove(<?php echo e($requirement->id); ?>, 'table-two')" type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target=".bd-example-modal-lg">
                                                    <i class="fas fa-solid fa-times"></i>
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3">
                                        Essa ordem ainda não foi atendida
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <form id="form" action="<?php echo e(route('file.upload.operador')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="order_id" value="<?php echo e($order_id); ?>">
                        <label for="file">Anexar dois anexos (01 obrigatório outro opcional)</label>
                        <?php if(isset($op) && $op->file == null): ?>
                            <div class="d-flex flex-row justify-content-between">
                                <div>
                                    <input type="file" name="2" required>
                                    <?php $__errorArgs = ['requirement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" style="display: revert;" role="alert">
                                            <strong>
                                                Este documento é obrigatório.
                                            </strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div>
                                    <input type="file" name="3">
                                    <?php $__errorArgs = ['requirement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" style="display: revert;" role="alert">
                                            <strong>
                                                Este documento é obrigatório.
                                            </strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <button onclick="submit()" class="btn btn-primary float-sm-right">
                                    Enviar
                                </button>
                            </div>
                        <?php elseif(isset($op) && $op->file != null): ?>
                            <br>
                            <strong>Imagens já foram salvas!</strong>
                        <?php else: ?>
                            <br>
                            <strong>Essa ordem ainda não foi atendida </strong>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <a href="<?php echo e(route('testefinal')); ?>" class="btn btn-default float-sm-right mr-2">
                Voltar
            </a>

        </div>
    </div>
    <!-- Modal -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        function submit() {
            document.getElementById("form").submit();
        }

    function aprove(id, table) {
        $.ajax({
            url: "/file/approve/" + id,
            type: "POST",
            data: {
                id: id,
                table: table,
                type: '<?php echo e($type); ?>',
                _token: "<?php echo e(csrf_token()); ?>"
            },
            success: function (data) {
                if (data.data.table == 'table-one') {
                    $('.table-one').html(data.data.html);
                } else {
                    $('.table-two').html(data.data.html);
                }
            }
        });
    }
    function reprove(id, table) {
        $.ajax({
            url: "/file/reprove/" + id,
            type: "POST",
            data: {
                id: id,
                table: table,
                type: '<?php echo e($type); ?>',
                _token: "<?php echo e(csrf_token()); ?>"
            },
            success: function (data) {
                if (data.data.table == 'table-one') {
                    $('.table-one').html(data.data.html);
                } else {
                    $('.table-two').html(data.data.html);
                }
            }
        });
    }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/hcontr25/tlp.gestaoderecursos.com/resources/views/files/edit.blade.php ENDPATH**/ ?>