<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RvController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $req)
    { 
        
        $dados = [];
        
        if ($req->gerente != 'TODOS' || !isset($req->gerente)) {
            $filtroG = " and GERENTE = '".$req->gerente."' ";
        } else {
            $filtroG = '';
        } 
        
        if ($req->coordenador != 'TODOS' || !isset($req->coordenador)) {
            $filtroC = " and COORDENADOR = '".$req->coordenador."' ";
        } else {
            $filtroC = '';
        }
        
        if ($req->supervisor != 'TODOS' || !isset($req->supervisor)) {
            $filtroS = " and SUPERVISOR = '".$req->supervisor."' ";
        } else {
            $filtroS = '';
        }
        
        if ($req->referencia != 'TODOS' || !isset($req->referencia)) {
            $filtroR = " and REFERENCIA = '".$req->referencia."' ";
        } else {
            $filtroR = '';
        }
      
        $dados['referencia'] = DB::select("Select REFERENCIA as referencia
                                FROM `bonificacao` where REFERENCIA != 'REFERENCIA'
                                group by REFERENCIA order by REFERENCIA");
        
        $dados['gerente'] = DB::select("Select GERENTE as gerente
                                FROM `bonificacao` where GERENTE != 'GERENTE'
                                group by GERENTE order by GERENTE");
        
        $dados['coordenador'] = DB::select("Select COORDENADOR as coordenador
                                FROM `bonificacao`  where GERENTE != 'GERENTE'
                                group by COORDENADOR order by COORDENADOR");
                                
        $dados['supervisor'] = DB::select("Select SUPERVISOR as supervisor
                                FROM `bonificacao`  where GERENTE != 'GERENTE'
                                group by SUPERVISOR order by SUPERVISOR");
        $dados['atualizacao'] = DB::select("Select ATUALIZACAO as input
                                FROM `bonificacao` 
                                order by ATUALIZACAO desc limit 1");

      
        $dados['HCELEGIVEL'] = DB::Select("select COUNT(NOME) AS qtd from bonificacao WHERE SITUACAO = '1' $filtroG $filtroC $filtroS $filtroR");
        $dados['VLELEGIVEL'] = DB::Select("select SUM(VALOR_TOTAL) AS qtd from bonificacao WHERE SITUACAO = '1' $filtroG $filtroC $filtroS $filtroR");
        $dados['HCINELEGIVEL'] = DB::Select("select COUNT(NOME) AS qtd from bonificacao WHERE SITUACAO = '0' $filtroG $filtroC $filtroS $filtroR");
        $dados['VLINELEGIVEL'] = DB::Select("select SUM(VALOR_TOTAL) AS qtd from bonificacao WHERE SITUACAO = '0' $filtroG $filtroC $filtroS $filtroR");

        $dados['acessos'] = DB::Select("select count(name) AS qtd from users WHERE tipo in ('reparador', 'instalador') ");
        $dados['alteracao_senha'] = DB::Select("select count(name) AS qtd from users WHERE tipo in ('reparador', 'instalador') and data_alteracao_senha is null");
        $dados['nunca_acessaram'] = DB::Select("select count(name) AS qtd from users WHERE tipo in ('reparador', 'instalador') and ultimo_login is null");
        $dados['acessaram'] = DB::Select("select count(name) AS qtd from users WHERE tipo in ('reparador', 'instalador') and ultimo_login is not null");
        $dados['usuarios'] = DB::Select("select * from users WHERE tipo in ('reparador', 'instalador') ");
        $dados['assinatura'] = DB::Select("select COUNT(NOME) AS qtd from bonificacao WHERE PAGO = 'S' and login_deacordo = '0'");
        
        $dados['informacao'] = DB::Select("select * from bonificacao ");            
        
        
        if (!isset($req['status']) || $req['status'] == '') {
            $dados['informacao'] = DB::Select("select * from bonificacao where STATUS_GERAL_TEC != 'STATUS_GERAL_TEC' $filtroG $filtroC $filtroS");            
        } else {
            
            if ($req['status'] == 'inelegiveis') {
                $dados['informacao'] = DB::Select("select * from bonificacao where SITUACAO = 0 and STATUS_GERAL_TEC != 'STATUS_GERAL_TEC' $filtroG $filtroC $filtroS");
            }
            
            if ($req['status'] == 'elegiveis') {
                $dados['informacao'] = DB::Select("select * from bonificacao where SITUACAO = 1 and STATUS_GERAL_TEC != 'STATUS_GERAL_TEC' $filtroG $filtroC $filtroS");
            } 
            if ($req['status'] == 'pendente_assinatura') {
                $dados['informacao'] = DB::Select("select * from bonificacao WHERE PAGO = 'S' and login_deacordo = '0' $filtroG $filtroC $filtroS");
            } 
        }
        
        
        return view('rv',['dados' => $dados]);
    }

    public function index1(Request $req)
    { 
        $dados = [];
        $dados['acessos'] = DB::Select("select count(name) AS qtd from users WHERE tipo in ('reparador', 'instalador') ");
        $dados['alteracao_senha'] = DB::Select("select count(name) AS qtd from users WHERE tipo in ('reparador', 'instalador') and data_alteracao_senha is null");
        $dados['nunca_acessaram'] = DB::Select("select count(name) AS qtd from users WHERE tipo in ('reparador', 'instalador') and ultimo_login is null");
        $dados['acessaram'] = DB::Select("select count(name) AS qtd from users WHERE tipo in ('reparador', 'instalador') and ultimo_login is not null");
        $dados['usuarios'] = DB::Select("select * from users WHERE tipo in ('reparador', 'instalador') ");
    
        if (!isset($req['status']) || $req['status'] == '') {
            $dados['usuarios'] = DB::Select("select * from users WHERE tipo in ('reparador', 'instalador') ");
        } else {
            
            if ($req['status'] == 'alteracao_senha') {
                $dados['usuarios'] = DB::Select("select * from users WHERE tipo in ('reparador', 'instalador')  and data_alteracao_senha is null");
            }
            
            if ($req['status'] == 'nunca_acessaram') {
                $dados['usuarios'] = DB::Select("select * from users WHERE tipo in ('reparador', 'instalador')  and ultimo_login is null");
            } 
            if ($req['status'] == 'acessaram') {
                $dados['usuarios'] = DB::Select("select * from users WHERE tipo in ('reparador', 'instalador') and ultimo_login is not null");
            } 
        }
        return view('rv1',['dados' => $dados]);
    }

    public function ver(Request $req)
    { 
        $id = $req->id;
        $dados = [];
        $dados['informacao'] = DB::Select("select * from bonificacao where id_ = $id");
        return view('visualizar_rv',['dados' => $dados]);
    }
}
    