



<?php $__env->startSection('title', 'Cadastro'); ?>

<?php $__env->startSection('content_header'); ?>
<?php $__env->stopSection(); ?>
<?php //dd($dados['funcionarios']);?>
<?php $__env->startSection('content'); ?>
    <div class="callout callout-info">
     
      </div>
      <div class="callout callout-info">
    <div class="row">
        <!-- left column -->
        <div class="col-lg-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" action="./editar_usuario_alterar">
              <div class="box-body">

                <?php echo e(csrf_field()); ?>

              <br>
                <div class="col-lg-12">     
                  <h5 style="color:#;"><b>Dados da Básicos</b></h5>
                 
                  <hr>
              <div class="row">
                
                 
                     <div class="form-group col-md-2">
                        <label for="exampleInputEmail1">ID:</label>
                        <input type="text" class="form-control form-control-sm" name="id" style="background:#" value="<?php echo  $dados['dados'][0]->id;?>" readonly="">
                    </div>
                
                    <div class="form-group col-md-4">
                        <label for="exampleInputEmail1">Nome:</label>
                        <input type="text" class="form-control form-control-sm" name="name" style="background:#" value="<?php echo  $dados['dados'][0]->name;?>" required>
                    </div>
                      <div class="form-group col-md-6">
                        <label for="exampleInputEmail1">Equipe:</label>
                        <select name="gestao" class="form-control form-control-sm" value="">
                            <?php 
                            echo '<option value="'.$dados['dados'][0]->gestao.'">'.$dados['dados'][0]->gestao.' | Atual</option>';
                            foreach ($dados['supervisor'] as $coord) {
                                echo '<option value="'.$coord->supervisor.'">'.$coord->supervisor.'</option>';
                            }
                            
                            
                            ;?>
                          
                        </select>
                        </div>
                        
                           <div class="form-group col-md-6">
                        <label for="exampleInputEmail1">Equipe1:</label>
                        <select name="gestao1" class="form-control form-control-sm" value="">
                            <?php 
                            echo '<option value="'.$dados['dados'][0]->gestao1.'">'.$dados['dados'][0]->gestao1.' | Atual</option>';
                            echo '<option value="">Descredenciar</option>';
                            foreach ($dados['supervisor'] as $coord) {
                                echo '<option value="'.$coord->supervisor.'">'.$coord->supervisor.'</option>';
                            }
                            
                            
                            ;?>
                          
                        </select>
                        </div>
                        
                           <div class="form-group col-md-6">
                        <label for="exampleInputEmail1">Equipe2:</label>
                        <select name="gestao2" class="form-control form-control-sm" value="">
                            <?php 
                            echo '<option value="'.$dados['dados'][0]->gestao2.'">'.$dados['dados'][0]->gestao2.' | Atual</option>';
                            echo '<option value="">Descredenciar</option>';
                            foreach ($dados['supervisor'] as $coord) {
                                echo '<option value="'.$coord->supervisor.'">'.$coord->supervisor.'</option>';
                            }
                            
                            
                            ;?>
                          
                        </select>
                        </div>
                        
                        <div class="form-group col-md-6">
                        <label for="exampleInputEmail1">Utiliza agendamento?:</label>
                        <select name="agendamento" class="form-control form-control-sm" value="">
                            <?php 
                            if ($dados['dados'][0]->agendamento == 0) {
                                echo '<option value="'.$dados['dados'][0]->agendamento.'">Não | Atual</option>';
                            } else {
                                echo '<option value="'.$dados['dados'][0]->agendamento.'">Sim | Atual</option>';
                            }
                            ;?>
                            <option value="0">Não</option>';
                            <option value="1">Sim</option>';
                          
                        </select>
                        </div>
                        

                    <div class="form-group col-md-4">
                        <label for="exampleInputEmail1">Senha:</label>
                        <input type="password" class="form-control form-control-sm" name="senha" style="background:#" value="<?php echo  $dados['dados'][0]->password;?>" required>
                    </div>
                 
                        </div>
                 
                        
                        <br>
               
 <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {
        "packages":["map"],
        // Note: you will need to get a mapsApiKey for your project.
        // See: https://developers.google.com/chart/interactive/docs/basic_load_libs#load-settings
        "mapsApiKey": "AIzaSyC6a5-_Ba4h1gtx2EBj1wCnkJfJrAj_Huc"
      });
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Lat', 'Long', 'Name'],
          [37.4232, -122.0853, 'Work'],
          [37.4289, -122.1697, 'University'],
          [37.6153, -122.3900, 'Airport'],
          [37.4422, -122.1731, 'Shopping']
        ]);

        var map = new google.visualization.Map(document.getElementById('map_div'));
        map.draw(data, {
          showTooltip: true,
          showInfoWindow: true
        });
      }

    </script>
  </head>
<br>
<div class="box-footer">
                <button type="submit" class="btn btn-success">Salvar</button> </a>
                <a href="./index"><button type="button" class="btn btn-secondary">Retornar</button> </a>
              </div><br>
            </form>
          </div>
          <!-- /.box -->

         
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/hcontr25/gestaoderecursos.com/hc/resources/views/usuario/editar-usuario.blade.php ENDPATH**/ ?>