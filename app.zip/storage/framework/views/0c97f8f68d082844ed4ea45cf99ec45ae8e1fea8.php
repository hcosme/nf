<aside class="main-sidebar <?php echo e(config('adminlte.classes_sidebar', 'sidebar-dark-primary elevation-4')); ?>">

    
    <?php if(config('adminlte.logo_img_xl')): ?>
        <?php echo $__env->make('adminlte::partials.common.brand-logo-xl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('adminlte::partials.common.brand-logo-xs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <div class="sidebar">
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column <?php echo e(config('adminlte.classes_sidebar_nav', '')); ?>"
                data-widget="treeview" role="menu"
                <?php if(config('adminlte.sidebar_nav_animation_speed') != 300): ?>
                    data-animation-speed="<?php echo e(config('adminlte.sidebar_nav_animation_speed')); ?>"
                <?php endif; ?>
                <?php if(!config('adminlte.sidebar_nav_accordion')): ?>
                    data-accordion="false"
                <?php endif; ?>>
                
                <?php
                    // dd($adminlte->menu('sidebar'));
                    $params = [];
                   
                        if(Auth::user()->tf == 1) { 
                            $params['testefinal']    = $adminlte->menu('sidebar')[17];
                            $params['tf']    = $adminlte->menu('sidebar')[18];
                        } else {
                    
                        
                        $params['hc']   = $adminlte->menu('sidebar')[0];
                        
                        if(Auth::user()->perfil != 0){
                            $params['ft']    = $adminlte->menu('sidebar')[1];
                            $params['novo_tec']    = $adminlte->menu('sidebar')[2];
                        }
                        $params['apontar']    = $adminlte->menu('sidebar')[3];
                        $params['alterar_apontamento']     = $adminlte->menu('sidebar')[4];
                          $params['tabulador']     = $adminlte->menu('sidebar')[5];
                            $params['tabulador-instalacao']     = $adminlte->menu('sidebar')[6];
                            $params['tabulador-operadores']     = $adminlte->menu('sidebar')[7];
                      // VENDAS
                        $params['config']    = $adminlte->menu('sidebar')[8];
                        if(Auth::user()->perfil != 0){
                            $params['usuarios']     = $adminlte->menu('sidebar')[9];
                        }
                      
                        
                        $params['3logs']    = $adminlte->menu('sidebar')[21];
                        $params['config1']    = $adminlte->menu('sidebar')[10];
                          
                        
                        $params['os']    = $adminlte->menu('sidebar')[11];
                        $params['sla_bluephone']    = $adminlte->menu('sidebar')[12];
                        $params['repetido_bluephone']    = $adminlte->menu('sidebar')[13];
                        $params['logs']    = $adminlte->menu('sidebar')[14];
                        $params['1sla_bluephone']    = $adminlte->menu('sidebar')[15];
                        $params['1repetido_bluephone']    = $adminlte->menu('sidebar')[16];
                        $params['testefinal']    = $adminlte->menu('sidebar')[17];
                        $params['tf']    = $adminlte->menu('sidebar')[18];
                        
                        $params['1logs']    = $adminlte->menu('sidebar')[19];
                        $params['2logs']    = $adminlte->menu('sidebar')[20];
                        
                    }
                ;?>
                <?php echo $__env->renderEach('adminlte::partials.sidebar.menu-item', $params, 'item'); ?>
            </ul>
        </nav>
    </div>

</aside>
<?php /**PATH /home4/hcontr25/tlp.gestaoderecursos.com/resources/views/vendor/adminlte/partials/sidebar/left-sidebar.blade.php ENDPATH**/ ?>