<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta http-equiv="Content-Style-Type" content="text/css" />
      <meta name="generator" content="Aspose.Words for .NET 23.3.0" />
      <title></title>
      <style type="text/css">body { line-height:115%; font-family:Calibri; font-size:11pt }h1, p { margin:0pt 0pt 10pt }li, table { margin-top:0pt; margin-bottom:10pt }h1 { margin-bottom:0pt; text-align:center; page-break-inside:auto; page-break-after:avoid; line-height:normal; font-family:'Bookman Old Style'; font-size:11pt; font-weight:bold; color:#000000 }.BalloonText { margin-bottom:0pt; line-height:normal; font-family:Tahoma; font-size:8pt }.Footer { margin-bottom:0pt; line-height:normal; font-size:11pt }.Header { margin-bottom:0pt; line-height:normal; font-size:11pt }.ListParagraph { margin-left:36pt; margin-bottom:10pt; line-height:115%; font-size:11pt }.PlainText { margin-bottom:0pt; line-height:normal; font-family:Calibri; font-size:11pt }span.TextodebaloChar { font-family:Tahoma; font-size:8pt }span.TextosemFormataoChar { font-family:Calibri }span.Ttulo1Char { font-family:'Bookman Old Style'; font-weight:bold }.TableGrid {  }</style>
   <script>
        window.print();
   </script>
   </head>
   <body>
    <img class="d-block w-100" src="<?php echo (asset('../storage/app/public/advertencia/'.$dados['dados'][0]->anexo));?>">
   </body>
</html>